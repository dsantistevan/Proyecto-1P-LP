#Pygments Tk Text from http://code.google.com/p/pygments-tk-text/
#Original Developer: Jonathon Eunice: jonathan.eunice@gmail.com
__author__ = 'Robert Cope'
__original__author__ = 'Jonathan Eunice'

