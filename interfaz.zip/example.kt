val num = 1
var nombre = "Carlos Jimenez"
var lista = [1,2,3]
